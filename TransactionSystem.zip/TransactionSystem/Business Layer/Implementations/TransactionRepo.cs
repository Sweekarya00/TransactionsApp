﻿using Business_Layer.Interfaces;
using Data_Layer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Layer.Implementations
{
    public class TransactionRepo : ITransactionRepo
    {
        private readonly TransactionDbContext _context;

        public TransactionRepo(TransactionDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<TransactionDetail>> GetAllTransactions()
        {
            var transactions = await _context.TransactionDetails.ToListAsync();
            var sortedTransactions = transactions.OrderByDescending(transaction => transaction.Date).ToList();
            return sortedTransactions;
        }
        public async Task AddTransaction(TransactionDetail model)
        {
            var transactions = await _context.TransactionDetails.ToListAsync();
            var sortedTransactions = transactions.OrderByDescending(transaction => transaction.Date).ToList();
            var latestTransaction = sortedTransactions.FirstOrDefault(transaction => transaction.Id == 1);
            decimal balance = (latestTransaction.Balance == null) ? 0 : latestTransaction.Balance;
            if (model.Debit > 0)
            {
                if (balance < model.Debit)
                {
                    throw new InvalidOperationException("Insufficient funds");
                }
                balance -= model.Debit;
                model.Balance = balance;
            }
            if (model.Credit > 0)
            {
                balance += model.Credit;
                model.Balance = balance;
            }
            await _context.TransactionDetails.AddAsync(model);
            _context.SaveChanges();
        }
    }
}
