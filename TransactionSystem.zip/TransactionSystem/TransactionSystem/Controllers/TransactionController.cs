﻿using Business_Layer.Interfaces;
using Data_Layer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Razor;

namespace TransactionSystem.Controllers
{
    public class TransactionController : Controller
    {
        private readonly ITransactionRepo _transactionRepo;

        public TransactionController(ITransactionRepo transactionRepo)
        {
            _transactionRepo = transactionRepo;
        }

        public async Task<IActionResult> Index()
        {
            var transactions = await _transactionRepo.GetAllTransactions();
            return View(transactions);
        }

        [HttpGet]
        public async Task<IActionResult> Add()
        {
            return View(new TransactionDetail());
        }

        [HttpPost]
        public async Task<IActionResult> Add(TransactionDetail model)
        {
            if (ModelState.IsValid)
            {
                await _transactionRepo.AddTransaction(model);
                TempData["successMessage"] = "Transaction added successfully";
                return RedirectToAction(nameof(Index));
            }
            else
            {
                TempData["errorMessage"] = "Transaction invalid";
                return View();
            }
        }
    }
}
